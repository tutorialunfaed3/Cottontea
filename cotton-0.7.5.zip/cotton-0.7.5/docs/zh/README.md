---
home: true
heroText: Cotton
tagline: 用于 Deno 的 SQL 数据库工具包
actionText: 快速开始 →
actionLink: /zh/guide/
features:
  - title: 良好的测试覆盖
    details: 所有的功能都通过了多种类型的 SQL 数据库的测试。
  - title: 关系型映射对象
    details: 获取的记录将转换为可自定义的对象，这使您可以更轻松地添加自定义方法，钩子和 getter-setter 方法。
  - title: 强大的查询器
    details: 使用类型丰富但简单的 API 构建 SQL 查询。
footer: MIT Licensed | Copyright © 2020 Rahman Fadhil
---
